package raju;

public class Raju {

	public static void main(String[] args) {
	System.out.println("this is raju");

	}

}
